/*******************************************************************************
* File Name: isrUpdateDisplay.c  
* Version 1.70
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include <CYDEVICE_TRM.H>
#include <CYLIB.H>
#include <isrUpdateDisplay.H>

#if !defined(isrUpdateDisplay__REMOVED) /* Check for removal by optimization */

/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START isrUpdateDisplay_intc` */

/* `#END` */


/*******************************************************************************
* Function Name: isrUpdateDisplay_Start
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_Start(void) 
{
    /* For all we know the interrupt is active. */
    isrUpdateDisplay_Disable();

    /* Set the ISR to point to the isrUpdateDisplay Interrupt. */
    isrUpdateDisplay_SetVector(&isrUpdateDisplay_Interrupt);

    /* Set the priority. */
    isrUpdateDisplay_SetPriority((uint8)isrUpdateDisplay_INTC_PRIOR_NUMBER);

    /* Enable it. */
    isrUpdateDisplay_Enable();
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_StartEx
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_StartEx(cyisraddress address) 
{
    /* For all we know the interrupt is active. */
    isrUpdateDisplay_Disable();

    /* Set the ISR to point to the isrUpdateDisplay Interrupt. */
    isrUpdateDisplay_SetVector(address);

    /* Set the priority. */
    isrUpdateDisplay_SetPriority((uint8)isrUpdateDisplay_INTC_PRIOR_NUMBER);

    /* Enable it. */
    isrUpdateDisplay_Enable();
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_Stop
********************************************************************************
*
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_Stop(void) 
{
    /* Disable this interrupt. */
    isrUpdateDisplay_Disable();
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_Interrupt
********************************************************************************
* Summary:
*   The default Interrupt Service Routine for isrUpdateDisplay.
*
*   Add custom code between the coments to keep the next version of this file
*   from over writting your code.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
CY_ISR(isrUpdateDisplay_Interrupt)
{
    /*  Place your Interrupt code here. */
    /* `#START isrUpdateDisplay_Interrupt` */

    /* `#END` */

    /* PSoC3 ES1, ES2 RTC ISR PATCH  */ 
    #if(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3)
        #if((CYDEV_CHIP_REVISION_USED <= CYDEV_CHIP_REVISION_3A_ES2) && (isrUpdateDisplay__ES2_PATCH ))      
            isrUpdateDisplay_ISR_PATCH();
        #endif /* CYDEV_CHIP_REVISION_USED */
    #endif /* (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) */
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_SetVector
********************************************************************************
*
* Summary:
*   Change the ISR vector for the Interrupt. Note calling isrUpdateDisplay_Start
*   will override any effect this method would have had. To set the vector 
*   before the component has been started use isrUpdateDisplay_StartEx instead.
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_SetVector(cyisraddress address) 
{
    CY_SET_REG16(isrUpdateDisplay_INTC_VECTOR, (uint16) address);
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_GetVector
********************************************************************************
*
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*******************************************************************************/
cyisraddress isrUpdateDisplay_GetVector(void) 
{
    return (cyisraddress) CY_GET_REG16(isrUpdateDisplay_INTC_VECTOR);
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_SetPriority
********************************************************************************
*
* Summary:
*   Sets the Priority of the Interrupt. Note calling isrUpdateDisplay_Start
*   or isrUpdateDisplay_StartEx will override any effect this method would 
*   have had. This method should only be called after isrUpdateDisplay_Start or 
*   isrUpdateDisplay_StartEx has been called. To set the initial
*   priority for the component use the cydwr file in the tool.
*
* Parameters:
*   priority: Priority of the interrupt. 0 - 7, 0 being the highest.
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_SetPriority(uint8 priority) 
{
    *isrUpdateDisplay_INTC_PRIOR = priority << 5;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_GetPriority
********************************************************************************
*
* Summary:
*   Gets the Priority of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Priority of the interrupt. 0 - 7, 0 being the highest.
*
*******************************************************************************/
uint8 isrUpdateDisplay_GetPriority(void) 
{
    uint8 priority;


    priority = *isrUpdateDisplay_INTC_PRIOR >> 5;

    return priority;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_Enable
********************************************************************************
*
* Summary:
*   Enables the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_Enable(void) 
{
    /* Enable the general interrupt. */
    *isrUpdateDisplay_INTC_SET_EN = isrUpdateDisplay__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_GetState
********************************************************************************
*
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   1 if enabled, 0 if disabled.
*
*******************************************************************************/
uint8 isrUpdateDisplay_GetState(void) 
{
    /* Get the state of the general interrupt. */
    return ((*isrUpdateDisplay_INTC_SET_EN & (uint8)isrUpdateDisplay__INTC_MASK) != 0u) ? 1u:0u;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_Disable
********************************************************************************
*
* Summary:
*   Disables the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_Disable(void) 
{
    /* Disable the general interrupt. */
    *isrUpdateDisplay_INTC_CLR_EN = isrUpdateDisplay__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_SetPending
********************************************************************************
*
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_SetPending(void) 
{
    *isrUpdateDisplay_INTC_SET_PD = isrUpdateDisplay__INTC_MASK;
}


/*******************************************************************************
* Function Name: isrUpdateDisplay_ClearPending
********************************************************************************
*
* Summary:
*   Clears a pending interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void isrUpdateDisplay_ClearPending(void) 
{
    *isrUpdateDisplay_INTC_CLR_PD = isrUpdateDisplay__INTC_MASK;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
