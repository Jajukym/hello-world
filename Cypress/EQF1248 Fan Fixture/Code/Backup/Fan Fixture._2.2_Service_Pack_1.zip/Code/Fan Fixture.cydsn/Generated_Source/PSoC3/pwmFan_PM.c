/*******************************************************************************
* File Name: pwmFan_PM.c
* Version 2.40
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "pwmFan.h"

static pwmFan_backupStruct pwmFan_backup;


/*******************************************************************************
* Function Name: pwmFan_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  pwmFan_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void pwmFan_SaveConfig(void) 
{
    
    #if(!pwmFan_UsingFixedFunction)
        #if (CY_UDB_V0)
            pwmFan_backup.PWMUdb = pwmFan_ReadCounter();
            pwmFan_backup.PWMPeriod = pwmFan_ReadPeriod();
            #if (pwmFan_UseStatus)
                pwmFan_backup.InterruptMaskValue = pwmFan_STATUS_MASK;
            #endif /* (pwmFan_UseStatus) */
            
            #if(pwmFan_UseOneCompareMode)
                pwmFan_backup.PWMCompareValue = pwmFan_ReadCompare();
            #else
                pwmFan_backup.PWMCompareValue1 = pwmFan_ReadCompare1();
                pwmFan_backup.PWMCompareValue2 = pwmFan_ReadCompare2();
            #endif /* (pwmFan_UseOneCompareMode) */
            
           #if(pwmFan_DeadBandUsed)
                pwmFan_backup.PWMdeadBandValue = pwmFan_ReadDeadTime();
            #endif /* (pwmFan_DeadBandUsed) */
          
            #if ( pwmFan_KillModeMinTime)
                pwmFan_backup.PWMKillCounterPeriod = pwmFan_ReadKillTime();
            #endif /* ( pwmFan_KillModeMinTime) */
        #endif /* (CY_UDB_V0) */
        
        #if (CY_UDB_V1)
            #if(!pwmFan_PWMModeIsCenterAligned)
                pwmFan_backup.PWMPeriod = pwmFan_ReadPeriod();
            #endif /* (!pwmFan_PWMModeIsCenterAligned) */
            pwmFan_backup.PWMUdb = pwmFan_ReadCounter();
            #if (pwmFan_UseStatus)
                pwmFan_backup.InterruptMaskValue = pwmFan_STATUS_MASK;
            #endif /* (pwmFan_UseStatus) */
            
            #if(pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_256_CLOCKS || \
                pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_2_4_CLOCKS)
                pwmFan_backup.PWMdeadBandValue = pwmFan_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(pwmFan_KillModeMinTime)
                 pwmFan_backup.PWMKillCounterPeriod = pwmFan_ReadKillTime();
            #endif /* (pwmFan_KillModeMinTime) */
        #endif /* (CY_UDB_V1) */
        
        #if(pwmFan_UseControl)
            pwmFan_backup.PWMControlRegister = pwmFan_ReadControlRegister();
        #endif /* (pwmFan_UseControl) */
    #endif  /* (!pwmFan_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: pwmFan_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  pwmFan_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void pwmFan_RestoreConfig(void) 
{
        #if(!pwmFan_UsingFixedFunction)
            #if (CY_UDB_V0)
                /* Interrupt State Backup for Critical Region*/
                uint8 pwmFan_interruptState;
                /* Enter Critical Region*/
                pwmFan_interruptState = CyEnterCriticalSection();
                #if (pwmFan_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    pwmFan_STATUS_AUX_CTRL |= pwmFan_STATUS_ACTL_INT_EN_MASK;
                    
                    pwmFan_STATUS_MASK = pwmFan_backup.InterruptMaskValue;
                #endif /* (pwmFan_UseStatus) */
                
                #if (pwmFan_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    pwmFan_AUX_CONTROLDP0 |= (pwmFan_AUX_CTRL_FIFO0_CLR);
                #else /* (pwmFan_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    pwmFan_AUX_CONTROLDP0 |= (pwmFan_AUX_CTRL_FIFO0_CLR);
                    pwmFan_AUX_CONTROLDP1 |= (pwmFan_AUX_CTRL_FIFO0_CLR);
                #endif /* (pwmFan_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(pwmFan_interruptState);
                
                pwmFan_WriteCounter(pwmFan_backup.PWMUdb);
                pwmFan_WritePeriod(pwmFan_backup.PWMPeriod);
                
                #if(pwmFan_UseOneCompareMode)
                    pwmFan_WriteCompare(pwmFan_backup.PWMCompareValue);
                #else
                    pwmFan_WriteCompare1(pwmFan_backup.PWMCompareValue1);
                    pwmFan_WriteCompare2(pwmFan_backup.PWMCompareValue2);
                #endif /* (pwmFan_UseOneCompareMode) */
                
               #if(pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_256_CLOCKS || \
                   pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_2_4_CLOCKS)
                    pwmFan_WriteDeadTime(pwmFan_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( pwmFan_KillModeMinTime)
                    pwmFan_WriteKillTime(pwmFan_backup.PWMKillCounterPeriod);
                #endif /* ( pwmFan_KillModeMinTime) */
            #endif /* (CY_UDB_V0) */
            
            #if (CY_UDB_V1)
                #if(!pwmFan_PWMModeIsCenterAligned)
                    pwmFan_WritePeriod(pwmFan_backup.PWMPeriod);
                #endif /* (!pwmFan_PWMModeIsCenterAligned) */
                pwmFan_WriteCounter(pwmFan_backup.PWMUdb);
                #if (pwmFan_UseStatus)
                    pwmFan_STATUS_MASK = pwmFan_backup.InterruptMaskValue;
                #endif /* (pwmFan_UseStatus) */
                
                #if(pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_256_CLOCKS || \
                    pwmFan_DeadBandMode == pwmFan__B_PWM__DBM_2_4_CLOCKS)
                    pwmFan_WriteDeadTime(pwmFan_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(pwmFan_KillModeMinTime)
                    pwmFan_WriteKillTime(pwmFan_backup.PWMKillCounterPeriod);
                #endif /* (pwmFan_KillModeMinTime) */
            #endif /* (CY_UDB_V1) */
            
            #if(pwmFan_UseControl)
                pwmFan_WriteControlRegister(pwmFan_backup.PWMControlRegister); 
            #endif /* (pwmFan_UseControl) */
        #endif  /* (!pwmFan_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: pwmFan_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  pwmFan_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void pwmFan_Sleep(void) 
{
    #if(pwmFan_UseControl)
        if(pwmFan_CTRL_ENABLE == (pwmFan_CONTROL & pwmFan_CTRL_ENABLE))
        {
            /*Component is enabled */
            pwmFan_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            pwmFan_backup.PWMEnableState = 0u;
        }
    #endif /* (pwmFan_UseControl) */

    /* Stop component */
    pwmFan_Stop();
    
    /* Save registers configuration */
    pwmFan_SaveConfig();
}


/*******************************************************************************
* Function Name: pwmFan_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  None
*
* Return: 
*  None
*
* Global variables:
*  pwmFan_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void pwmFan_Wakeup(void) 
{
     /* Restore registers values */
    pwmFan_RestoreConfig();
    
    if(pwmFan_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        pwmFan_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
