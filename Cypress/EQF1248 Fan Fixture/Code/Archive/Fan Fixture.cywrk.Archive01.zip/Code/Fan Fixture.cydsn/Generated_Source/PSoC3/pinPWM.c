/*******************************************************************************
* File Name: pinPWM.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "pinPWM.h"


/*******************************************************************************
* Function Name: pinPWM_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void pinPWM_Write(uint8 value) 
{
    uint8 staticBits = (pinPWM_DR & (uint8)(~pinPWM_MASK));
    pinPWM_DR = staticBits | ((uint8)(value << pinPWM_SHIFT) & pinPWM_MASK);
}


/*******************************************************************************
* Function Name: pinPWM_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void pinPWM_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(pinPWM_0, mode);
}


/*******************************************************************************
* Function Name: pinPWM_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro pinPWM_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 pinPWM_Read(void) 
{
    return (pinPWM_PS & pinPWM_MASK) >> pinPWM_SHIFT;
}


/*******************************************************************************
* Function Name: pinPWM_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 pinPWM_ReadDataReg(void) 
{
    return (pinPWM_DR & pinPWM_MASK) >> pinPWM_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(pinPWM_INTSTAT) 

    /*******************************************************************************
    * Function Name: pinPWM_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 pinPWM_ClearInterrupt(void) 
    {
        return (pinPWM_INTSTAT & pinPWM_MASK) >> pinPWM_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
