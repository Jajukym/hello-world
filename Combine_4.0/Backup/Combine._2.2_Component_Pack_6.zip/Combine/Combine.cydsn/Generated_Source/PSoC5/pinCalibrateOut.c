/*******************************************************************************
* File Name: pinCalibrateOut.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "pinCalibrateOut.h"

/* APIs are not generated for P15[7:6] on PSoC 5 */
#if !(CY_PSOC5A &&\
	 pinCalibrateOut__PORT == 15 && ((pinCalibrateOut__MASK & 0xC0) != 0))


/*******************************************************************************
* Function Name: pinCalibrateOut_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None
*  
*******************************************************************************/
void pinCalibrateOut_Write(uint8 value) 
{
    uint8 staticBits = (pinCalibrateOut_DR & (uint8)(~pinCalibrateOut_MASK));
    pinCalibrateOut_DR = staticBits | ((uint8)(value << pinCalibrateOut_SHIFT) & pinCalibrateOut_MASK);
}


/*******************************************************************************
* Function Name: pinCalibrateOut_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void pinCalibrateOut_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(pinCalibrateOut_0, mode);
}


/*******************************************************************************
* Function Name: pinCalibrateOut_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro pinCalibrateOut_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 pinCalibrateOut_Read(void) 
{
    return (pinCalibrateOut_PS & pinCalibrateOut_MASK) >> pinCalibrateOut_SHIFT;
}


/*******************************************************************************
* Function Name: pinCalibrateOut_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 pinCalibrateOut_ReadDataReg(void) 
{
    return (pinCalibrateOut_DR & pinCalibrateOut_MASK) >> pinCalibrateOut_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(pinCalibrateOut_INTSTAT) 

    /*******************************************************************************
    * Function Name: pinCalibrateOut_ClearInterrupt
    ********************************************************************************
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 pinCalibrateOut_ClearInterrupt(void) 
    {
        return (pinCalibrateOut_INTSTAT & pinCalibrateOut_MASK) >> pinCalibrateOut_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 

#endif /* CY_PSOC5A... */

    
/* [] END OF FILE */
