

#include <device.h>

/* Functions */
void ButtonPress(void);
void UpdateDisplay(void);


/* Declares */
int     intButtonPress;
uint8   uint8Compare;
int     Pin12FanLevel;
int     Pin6FanLevel;
uint16  uint16ADC;
uint16  uint16FanV;
int     intVoltagePlace[4];
uint16   uint16Temp;
uint16  uint16LoV;
uint16  uint16HiV;
uint8   uint8Loop;
uint8   uint8Multiply;

void main()
{

    /* Starts */
    lcdDisplay_Start();
    pwmFan_Start();
    pwmFan2_Start();
    adcVFan_Start();
   
    
    /*Interrupts */
    isrButton_StartEx(ButtonPress); 
    isrUpdateDisplay_StartEx(UpdateDisplay);
    statusButtons_InterruptEnable();
    CyGlobalIntEnable;
    
    
    /* Run Once */
    lcdDisplay_ClearDisplay();
    lcdDisplay_Position(0,0);
    lcdDisplay_PrintString("Fan PWM:");
        lcdDisplay_Position(1,0);
    lcdDisplay_PrintString("Voltage:");
    adcVFan_StartConvert();
    
    /* Main Loop */
    for(;;)
    {
    
    
    	/* Get ADC Value */
		if (adcVFan_IsEndConversion(adcVFan_WAIT_FOR_RESULT) ) //Wait until ADC has good value
        	{
            uint16ADC = adcVFan_GetResult16();	//Get Compare number from ADC
            //Create Voltage Reading
		    uint16FanV = ((uint16ADC-15) / 2.33);  //Convert ADC to Voltage
            if (uint16FanV > 15000)
                uint16FanV = 0;
            uint16Temp = uint16FanV;

                 if (uint16Temp > 99)
                    {
                    uint16HiV = uint16Temp / 100;
                    uint16LoV = uint16Temp % 100;
                    }
                 else
                    {
                    uint16HiV = 0;
                    uint16LoV = uint16Temp;
                    }
                
                
			
            }
	
		
    
    }
}

CY_ISR(ButtonPress)
{

intButtonPress = statusButtons_Read();

switch (intButtonPress)
    {
    case 129:  //Up Button
        {
        if (Pin12FanLevel >= 95)
            Pin12FanLevel = 100;
        else
            Pin12FanLevel = Pin12FanLevel + 5;
            
        break;
        }
    case 130:  //Down Button
        {
        if (Pin12FanLevel <= 5)
            Pin12FanLevel = 0;
        else
            Pin12FanLevel = Pin12FanLevel - 5 ;
        break;
        }
    }
    pwmFan2_WriteCompare(Pin12FanLevel);
    pwmFan_WriteCompare(Pin12FanLevel);


}

CY_ISR(UpdateDisplay)
{
        lcdDisplay_Position(0,9);
        lcdDisplay_PrintNumber(pwmFan_ReadCompare());
        lcdDisplay_PrintString("%    ");
        lcdDisplay_Position(1,9);
        lcdDisplay_PrintNumber(uint16HiV);
        lcdDisplay_PrintString(".");
        lcdDisplay_PrintNumber(uint16LoV);
        lcdDisplay_PrintString("v   ");
 
        

}
/* [] END OF FILE */
