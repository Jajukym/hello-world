/*******************************************************************************
* File Name: lcdDisplay_LCDPort.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_lcdDisplay_LCDPort_ALIASES_H) /* Pins lcdDisplay_LCDPort_ALIASES_H */
#define CY_PINS_lcdDisplay_LCDPort_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define lcdDisplay_LCDPort_0		lcdDisplay_LCDPort__0__PC
#define lcdDisplay_LCDPort_1		lcdDisplay_LCDPort__1__PC
#define lcdDisplay_LCDPort_2		lcdDisplay_LCDPort__2__PC
#define lcdDisplay_LCDPort_3		lcdDisplay_LCDPort__3__PC
#define lcdDisplay_LCDPort_4		lcdDisplay_LCDPort__4__PC
#define lcdDisplay_LCDPort_5		lcdDisplay_LCDPort__5__PC
#define lcdDisplay_LCDPort_6		lcdDisplay_LCDPort__6__PC

#endif /* End Pins lcdDisplay_LCDPort_ALIASES_H */


/* [] END OF FILE */
