/*******************************************************************************
* File Name: pinUp.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_pinUp_H) /* Pins pinUp_H */
#define CY_PINS_pinUp_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "pinUp_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    pinUp_Write(uint8 value) ;
void    pinUp_SetDriveMode(uint8 mode) ;
uint8   pinUp_ReadDataReg(void) ;
uint8   pinUp_Read(void) ;
uint8   pinUp_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define pinUp_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define pinUp_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define pinUp_DM_RES_UP          PIN_DM_RES_UP
#define pinUp_DM_RES_DWN         PIN_DM_RES_DWN
#define pinUp_DM_OD_LO           PIN_DM_OD_LO
#define pinUp_DM_OD_HI           PIN_DM_OD_HI
#define pinUp_DM_STRONG          PIN_DM_STRONG
#define pinUp_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define pinUp_MASK               pinUp__MASK
#define pinUp_SHIFT              pinUp__SHIFT
#define pinUp_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define pinUp_PS                     (* (reg8 *) pinUp__PS)
/* Data Register */
#define pinUp_DR                     (* (reg8 *) pinUp__DR)
/* Port Number */
#define pinUp_PRT_NUM                (* (reg8 *) pinUp__PRT) 
/* Connect to Analog Globals */                                                  
#define pinUp_AG                     (* (reg8 *) pinUp__AG)                       
/* Analog MUX bux enable */
#define pinUp_AMUX                   (* (reg8 *) pinUp__AMUX) 
/* Bidirectional Enable */                                                        
#define pinUp_BIE                    (* (reg8 *) pinUp__BIE)
/* Bit-mask for Aliased Register Access */
#define pinUp_BIT_MASK               (* (reg8 *) pinUp__BIT_MASK)
/* Bypass Enable */
#define pinUp_BYP                    (* (reg8 *) pinUp__BYP)
/* Port wide control signals */                                                   
#define pinUp_CTL                    (* (reg8 *) pinUp__CTL)
/* Drive Modes */
#define pinUp_DM0                    (* (reg8 *) pinUp__DM0) 
#define pinUp_DM1                    (* (reg8 *) pinUp__DM1)
#define pinUp_DM2                    (* (reg8 *) pinUp__DM2) 
/* Input Buffer Disable Override */
#define pinUp_INP_DIS                (* (reg8 *) pinUp__INP_DIS)
/* LCD Common or Segment Drive */
#define pinUp_LCD_COM_SEG            (* (reg8 *) pinUp__LCD_COM_SEG)
/* Enable Segment LCD */
#define pinUp_LCD_EN                 (* (reg8 *) pinUp__LCD_EN)
/* Slew Rate Control */
#define pinUp_SLW                    (* (reg8 *) pinUp__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define pinUp_PRTDSI__CAPS_SEL       (* (reg8 *) pinUp__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define pinUp_PRTDSI__DBL_SYNC_IN    (* (reg8 *) pinUp__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define pinUp_PRTDSI__OE_SEL0        (* (reg8 *) pinUp__PRTDSI__OE_SEL0) 
#define pinUp_PRTDSI__OE_SEL1        (* (reg8 *) pinUp__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define pinUp_PRTDSI__OUT_SEL0       (* (reg8 *) pinUp__PRTDSI__OUT_SEL0) 
#define pinUp_PRTDSI__OUT_SEL1       (* (reg8 *) pinUp__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define pinUp_PRTDSI__SYNC_OUT       (* (reg8 *) pinUp__PRTDSI__SYNC_OUT) 


#if defined(pinUp__INTSTAT)  /* Interrupt Registers */

    #define pinUp_INTSTAT                (* (reg8 *) pinUp__INTSTAT)
    #define pinUp_SNAP                   (* (reg8 *) pinUp__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins pinUp_H */


/* [] END OF FILE */
