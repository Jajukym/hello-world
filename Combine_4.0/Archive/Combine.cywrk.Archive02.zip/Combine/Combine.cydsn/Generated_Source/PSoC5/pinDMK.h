/*******************************************************************************
* File Name: pinDMK.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_pinDMK_H) /* Pins pinDMK_H */
#define CY_PINS_pinDMK_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "pinDMK_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 pinDMK__PORT == 15 && ((pinDMK__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    pinDMK_Write(uint8 value) ;
void    pinDMK_SetDriveMode(uint8 mode) ;
uint8   pinDMK_ReadDataReg(void) ;
uint8   pinDMK_Read(void) ;
uint8   pinDMK_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define pinDMK_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define pinDMK_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define pinDMK_DM_RES_UP          PIN_DM_RES_UP
#define pinDMK_DM_RES_DWN         PIN_DM_RES_DWN
#define pinDMK_DM_OD_LO           PIN_DM_OD_LO
#define pinDMK_DM_OD_HI           PIN_DM_OD_HI
#define pinDMK_DM_STRONG          PIN_DM_STRONG
#define pinDMK_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define pinDMK_MASK               pinDMK__MASK
#define pinDMK_SHIFT              pinDMK__SHIFT
#define pinDMK_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define pinDMK_PS                     (* (reg8 *) pinDMK__PS)
/* Data Register */
#define pinDMK_DR                     (* (reg8 *) pinDMK__DR)
/* Port Number */
#define pinDMK_PRT_NUM                (* (reg8 *) pinDMK__PRT) 
/* Connect to Analog Globals */                                                  
#define pinDMK_AG                     (* (reg8 *) pinDMK__AG)                       
/* Analog MUX bux enable */
#define pinDMK_AMUX                   (* (reg8 *) pinDMK__AMUX) 
/* Bidirectional Enable */                                                        
#define pinDMK_BIE                    (* (reg8 *) pinDMK__BIE)
/* Bit-mask for Aliased Register Access */
#define pinDMK_BIT_MASK               (* (reg8 *) pinDMK__BIT_MASK)
/* Bypass Enable */
#define pinDMK_BYP                    (* (reg8 *) pinDMK__BYP)
/* Port wide control signals */                                                   
#define pinDMK_CTL                    (* (reg8 *) pinDMK__CTL)
/* Drive Modes */
#define pinDMK_DM0                    (* (reg8 *) pinDMK__DM0) 
#define pinDMK_DM1                    (* (reg8 *) pinDMK__DM1)
#define pinDMK_DM2                    (* (reg8 *) pinDMK__DM2) 
/* Input Buffer Disable Override */
#define pinDMK_INP_DIS                (* (reg8 *) pinDMK__INP_DIS)
/* LCD Common or Segment Drive */
#define pinDMK_LCD_COM_SEG            (* (reg8 *) pinDMK__LCD_COM_SEG)
/* Enable Segment LCD */
#define pinDMK_LCD_EN                 (* (reg8 *) pinDMK__LCD_EN)
/* Slew Rate Control */
#define pinDMK_SLW                    (* (reg8 *) pinDMK__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define pinDMK_PRTDSI__CAPS_SEL       (* (reg8 *) pinDMK__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define pinDMK_PRTDSI__DBL_SYNC_IN    (* (reg8 *) pinDMK__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define pinDMK_PRTDSI__OE_SEL0        (* (reg8 *) pinDMK__PRTDSI__OE_SEL0) 
#define pinDMK_PRTDSI__OE_SEL1        (* (reg8 *) pinDMK__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define pinDMK_PRTDSI__OUT_SEL0       (* (reg8 *) pinDMK__PRTDSI__OUT_SEL0) 
#define pinDMK_PRTDSI__OUT_SEL1       (* (reg8 *) pinDMK__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define pinDMK_PRTDSI__SYNC_OUT       (* (reg8 *) pinDMK__PRTDSI__SYNC_OUT) 


#if defined(pinDMK__INTSTAT)  /* Interrupt Registers */

    #define pinDMK_INTSTAT                (* (reg8 *) pinDMK__INTSTAT)
    #define pinDMK_SNAP                   (* (reg8 *) pinDMK__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_pinDMK_H */


/* [] END OF FILE */
