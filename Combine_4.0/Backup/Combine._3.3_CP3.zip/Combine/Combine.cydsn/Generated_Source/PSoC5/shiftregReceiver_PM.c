/*******************************************************************************
* File Name: shiftregReceiver_PM.c
* Version 2.10
*
* Description:
*  This file provides the API source code for sleep mode support for Shift 
*  Register component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "shiftregReceiver.h"


static shiftregReceiver_BACKUP_STRUCT shiftregReceiver_backup = \
{
    /* enable state - disabled */
    0u
};


/*******************************************************************************
* Function Name: shiftregReceiver_SaveConfig
********************************************************************************
*
* Summary:
*  Saves Shift Register configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void shiftregReceiver_SaveConfig(void) 
{
    /* Store A0, A1 and Status Mask registers */
    #if (CY_UDB_V0)
       shiftregReceiver_backup.saveSrA0Reg   = CY_GET_REG8(shiftregReceiver_SHIFT_REG_LSB_PTR);
       shiftregReceiver_backup.saveSrA1Reg   = CY_GET_REG8(shiftregReceiver_SHIFT_REG_VALUE_LSB_PTR);
       shiftregReceiver_backup.saveSrIntMask = shiftregReceiver_SR_STATUS_MASK;

    #else
    /* Store A0, A1 only (not need to save Status Mask register  in ES3 silicon) */
       shiftregReceiver_backup.saveSrA0Reg   = CY_GET_REG8(shiftregReceiver_SHIFT_REG_LSB_PTR);
       shiftregReceiver_backup.saveSrA1Reg   = CY_GET_REG8(shiftregReceiver_SHIFT_REG_VALUE_LSB_PTR);

    #endif /* CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: shiftregReceiver_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores Shift Register configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void shiftregReceiver_RestoreConfig(void) 
{
    /* Restore tha data, saved by SaveConfig()function */
    #if (CY_UDB_V0)
        CY_SET_REG8(shiftregReceiver_SHIFT_REG_LSB_PTR, shiftregReceiver_backup.saveSrA0Reg);
            CY_SET_REG8(shiftregReceiver_SHIFT_REG_VALUE_LSB_PTR, shiftregReceiver_backup.saveSrA1Reg);
            shiftregReceiver_SR_STATUS_MASK = shiftregReceiver_backup.saveSrIntMask;
    #else
            CY_SET_REG8(shiftregReceiver_SHIFT_REG_LSB_PTR, shiftregReceiver_backup.saveSrA0Reg);
            CY_SET_REG8(shiftregReceiver_SHIFT_REG_VALUE_LSB_PTR, shiftregReceiver_backup.saveSrA1Reg);

    #endif /* CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: shiftregReceiver_Sleep
********************************************************************************
*
* Summary:
*  Prepare the component to enter a Sleep mode.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No. 
*
*******************************************************************************/
void shiftregReceiver_Sleep(void) 
{
    if((shiftregReceiver_SR_CONTROL & shiftregReceiver_CLK_EN) == shiftregReceiver_CLK_EN)
    {
        shiftregReceiver_backup.enableState = 1u;
    }
    else
    {
        shiftregReceiver_backup.enableState = 0u;
    }
    
    shiftregReceiver_Stop();
    shiftregReceiver_SaveConfig();
}


/*******************************************************************************
* Function Name: shiftregReceiver_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void shiftregReceiver_Wakeup(void) 
{
    shiftregReceiver_RestoreConfig();
    
    if(shiftregReceiver_backup.enableState == 1u)
    {
        shiftregReceiver_Enable();   
    }
}

/* [] END OF FILE */
