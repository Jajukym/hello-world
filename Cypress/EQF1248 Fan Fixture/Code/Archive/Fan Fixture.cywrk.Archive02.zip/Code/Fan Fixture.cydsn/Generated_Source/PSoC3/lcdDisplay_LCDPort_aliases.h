/*******************************************************************************
* File Name: lcdDisplay_LCDPort.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_lcdDisplay_LCDPort_ALIASES_H) /* Pins lcdDisplay_LCDPort_ALIASES_H */
#define CY_PINS_lcdDisplay_LCDPort_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define lcdDisplay_LCDPort_0			(lcdDisplay_LCDPort__0__PC)
#define lcdDisplay_LCDPort_0_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__0__SHIFT))

#define lcdDisplay_LCDPort_1			(lcdDisplay_LCDPort__1__PC)
#define lcdDisplay_LCDPort_1_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__1__SHIFT))

#define lcdDisplay_LCDPort_2			(lcdDisplay_LCDPort__2__PC)
#define lcdDisplay_LCDPort_2_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__2__SHIFT))

#define lcdDisplay_LCDPort_3			(lcdDisplay_LCDPort__3__PC)
#define lcdDisplay_LCDPort_3_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__3__SHIFT))

#define lcdDisplay_LCDPort_4			(lcdDisplay_LCDPort__4__PC)
#define lcdDisplay_LCDPort_4_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__4__SHIFT))

#define lcdDisplay_LCDPort_5			(lcdDisplay_LCDPort__5__PC)
#define lcdDisplay_LCDPort_5_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__5__SHIFT))

#define lcdDisplay_LCDPort_6			(lcdDisplay_LCDPort__6__PC)
#define lcdDisplay_LCDPort_6_INTR	((uint16)((uint16)0x0001u << lcdDisplay_LCDPort__6__SHIFT))

#define lcdDisplay_LCDPort_INTR_ALL	 ((uint16)(lcdDisplay_LCDPort_0_INTR| lcdDisplay_LCDPort_1_INTR| lcdDisplay_LCDPort_2_INTR| lcdDisplay_LCDPort_3_INTR| lcdDisplay_LCDPort_4_INTR| lcdDisplay_LCDPort_5_INTR| lcdDisplay_LCDPort_6_INTR))

#endif /* End Pins lcdDisplay_LCDPort_ALIASES_H */


/* [] END OF FILE */
