/*******************************************************************************
* File Name: pinUp.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "pinUp.h"


/*******************************************************************************
* Function Name: pinUp_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void pinUp_Write(uint8 value) 
{
    uint8 staticBits = (pinUp_DR & (uint8)(~pinUp_MASK));
    pinUp_DR = staticBits | ((uint8)(value << pinUp_SHIFT) & pinUp_MASK);
}


/*******************************************************************************
* Function Name: pinUp_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void pinUp_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(pinUp_0, mode);
}


/*******************************************************************************
* Function Name: pinUp_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro pinUp_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 pinUp_Read(void) 
{
    return (pinUp_PS & pinUp_MASK) >> pinUp_SHIFT;
}


/*******************************************************************************
* Function Name: pinUp_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 pinUp_ReadDataReg(void) 
{
    return (pinUp_DR & pinUp_MASK) >> pinUp_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(pinUp_INTSTAT) 

    /*******************************************************************************
    * Function Name: pinUp_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 pinUp_ClearInterrupt(void) 
    {
        return (pinUp_INTSTAT & pinUp_MASK) >> pinUp_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
