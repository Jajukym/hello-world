/*******************************************************************************
* File Name: pinVFan.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_pinVFan_H) /* Pins pinVFan_H */
#define CY_PINS_pinVFan_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "pinVFan_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    pinVFan_Write(uint8 value) ;
void    pinVFan_SetDriveMode(uint8 mode) ;
uint8   pinVFan_ReadDataReg(void) ;
uint8   pinVFan_Read(void) ;
uint8   pinVFan_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define pinVFan_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define pinVFan_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define pinVFan_DM_RES_UP          PIN_DM_RES_UP
#define pinVFan_DM_RES_DWN         PIN_DM_RES_DWN
#define pinVFan_DM_OD_LO           PIN_DM_OD_LO
#define pinVFan_DM_OD_HI           PIN_DM_OD_HI
#define pinVFan_DM_STRONG          PIN_DM_STRONG
#define pinVFan_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define pinVFan_MASK               pinVFan__MASK
#define pinVFan_SHIFT              pinVFan__SHIFT
#define pinVFan_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define pinVFan_PS                     (* (reg8 *) pinVFan__PS)
/* Data Register */
#define pinVFan_DR                     (* (reg8 *) pinVFan__DR)
/* Port Number */
#define pinVFan_PRT_NUM                (* (reg8 *) pinVFan__PRT) 
/* Connect to Analog Globals */                                                  
#define pinVFan_AG                     (* (reg8 *) pinVFan__AG)                       
/* Analog MUX bux enable */
#define pinVFan_AMUX                   (* (reg8 *) pinVFan__AMUX) 
/* Bidirectional Enable */                                                        
#define pinVFan_BIE                    (* (reg8 *) pinVFan__BIE)
/* Bit-mask for Aliased Register Access */
#define pinVFan_BIT_MASK               (* (reg8 *) pinVFan__BIT_MASK)
/* Bypass Enable */
#define pinVFan_BYP                    (* (reg8 *) pinVFan__BYP)
/* Port wide control signals */                                                   
#define pinVFan_CTL                    (* (reg8 *) pinVFan__CTL)
/* Drive Modes */
#define pinVFan_DM0                    (* (reg8 *) pinVFan__DM0) 
#define pinVFan_DM1                    (* (reg8 *) pinVFan__DM1)
#define pinVFan_DM2                    (* (reg8 *) pinVFan__DM2) 
/* Input Buffer Disable Override */
#define pinVFan_INP_DIS                (* (reg8 *) pinVFan__INP_DIS)
/* LCD Common or Segment Drive */
#define pinVFan_LCD_COM_SEG            (* (reg8 *) pinVFan__LCD_COM_SEG)
/* Enable Segment LCD */
#define pinVFan_LCD_EN                 (* (reg8 *) pinVFan__LCD_EN)
/* Slew Rate Control */
#define pinVFan_SLW                    (* (reg8 *) pinVFan__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define pinVFan_PRTDSI__CAPS_SEL       (* (reg8 *) pinVFan__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define pinVFan_PRTDSI__DBL_SYNC_IN    (* (reg8 *) pinVFan__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define pinVFan_PRTDSI__OE_SEL0        (* (reg8 *) pinVFan__PRTDSI__OE_SEL0) 
#define pinVFan_PRTDSI__OE_SEL1        (* (reg8 *) pinVFan__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define pinVFan_PRTDSI__OUT_SEL0       (* (reg8 *) pinVFan__PRTDSI__OUT_SEL0) 
#define pinVFan_PRTDSI__OUT_SEL1       (* (reg8 *) pinVFan__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define pinVFan_PRTDSI__SYNC_OUT       (* (reg8 *) pinVFan__PRTDSI__SYNC_OUT) 


#if defined(pinVFan__INTSTAT)  /* Interrupt Registers */

    #define pinVFan_INTSTAT                (* (reg8 *) pinVFan__INTSTAT)
    #define pinVFan_SNAP                   (* (reg8 *) pinVFan__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins pinVFan_H */


/* [] END OF FILE */
