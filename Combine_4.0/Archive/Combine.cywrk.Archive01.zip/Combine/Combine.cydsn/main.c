/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

#define forever 1

CY_ISR_PROTO(StoreISR);



int pinDMK;
uint8 statusButtonRead;
uint8 Polar_C_Pulse_Count;
uint8 Polar_S_Pulse_Count;
uint8 ANT_Pulse_Count;
uint8 ShiftData[255];

void InitializeHardware()
{
	CyGlobalIntEnable;
	isrStoreInt_StartEx(StoreISR);
    LCD_Start();
    LCD_ClearDisplay();
    pgaPolarC_Start();                                    //Polar Chest Pulse buffer
    counterPolarC_Start();
    pgaPolarS_Start();                                    //Polar Hand Pulse buffer
    counterPolarS_Start();
    pgaANTPlus_Start();                                  //ANT+ Chest Pulse buffer
    counterANTPlus_Start();
	counterShift_Start();                                //Membrane Button Read components
    shiftregSender_Start();
    shiftregSender_WriteData(0x00);
    CyDelay(250);
    shiftregReceiver_Start();	 
}
//***********************************************************************************

void main()
{
    //uint8 ii = 0x00;      //Calibration
    uint8 Status;
	InitializeHardware();
    clockShift_SetDivider(128);
    LCD_Position(0,8);
    LCD_PrintString("BETA");
    LCD_Position(1,0);
    LCD_PrintString("DMK:");
    LCD_Position(2,0);
    LCD_PrintString("Buttons:");
    LCD_Position(3,0);
    LCD_PrintString("Pulse:");
    
    
    for(;;)
    {
        if (pinDMK_Read() == 0)                     //DMK function
        {
            LCD_Position(1,5);
            LCD_PrintString("ON ");
        }
        else
        {
            LCD_Position(1,5);
            LCD_PrintString("OFF");
        }
        
        
    	
    		if(!((Status = shiftregSender_GetFIFOStatus(shiftregSender_IN_FIFO)) == shiftregSender_RET_FIFO_FULL))
    		{
    			//shiftregSender_WriteData(++ii);//FOR CALIBRATION ONLY. WILL COUNT UP FROM 0X00 TO 0XFF.//
                {
                    LCD_Position(2,9);
                    LCD_PrintInt8(shiftregReceiver_ReadData());
                }
    		}
        
    }
}
/*END OF FILE */


/************************************************************************************/
CY_ISR(StoreISR)
{
uint8 Status;
	while((Status = shiftregReceiver_GetFIFOStatus(shiftregReceiver_OUT_FIFO)) == shiftregReceiver_RET_FIFO_NOT_EMPTY)
	{
		shiftregReceiver_ReadData();   
	}
}